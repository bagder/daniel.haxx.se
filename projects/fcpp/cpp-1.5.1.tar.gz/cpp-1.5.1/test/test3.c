#include "stdarg.h"
#define blaha(x) tjo x jot __LINE__

 int (*test)();
Boolean ninja(hej)
	 Widget *hej;
{
va_start(ett, tva);
 /* gogo */
blaha(55)
line number:  __LINE__
function name:  __FUNCTION__
function line:  __FUNC_LINE__
}

koko Todeloo(char *tjo)
{
  __FUNCTION__
}

Boolean koko(hej)
	 Widget hej;
{
 /* gogo */
  __FUNCTION__
  __FUNC_LINE__
}
