
This is the include file

#define Fred Harry
