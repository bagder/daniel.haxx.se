

Hi this file has an alternate comment syntax ie

;; This is a comment so I can do Date : 12-09-2002

We also have an alternate number syntax ie

val = #009F  ;; This is the same as 0X009F
