#define cat(x, y)   x ## y
#define var123	    Werkt!!!
cat(var, 123);
cat(cat(1, 2), 3);
#define cat2(x, y)  x/**/y
cat2(var, 123);
cat2(cat2(1, 2), 3);
#define str(arg)    #arg
str("Hallo");
str(Ha"l"lo);
#define instr(x)    "x y" "x"
instr(Dit is de tweede string)
#define spaces	    a	b    c \
		nexy line
#define zeroargs()

testa C++ kommentarer!!! // hahahahha!!!!

litemer: /// wehweewr
///sfdsdfsd
ehehe // sdfsdfdfsfsdsf

{




}


/*


*/
heah
