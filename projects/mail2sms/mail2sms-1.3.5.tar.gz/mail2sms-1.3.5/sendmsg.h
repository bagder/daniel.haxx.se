int smsit(char *message);
