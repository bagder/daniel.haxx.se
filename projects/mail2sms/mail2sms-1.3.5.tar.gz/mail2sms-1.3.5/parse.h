struct body *  process(char *,    /* file name */
		       int , /* read from stdin */
		       int );   /* only one mail */
